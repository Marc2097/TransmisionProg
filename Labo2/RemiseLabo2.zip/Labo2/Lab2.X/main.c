/**
  @file   main.c, projet:
  @author Marc-Antoine Grenier (avec certaines parties fournit par l'enseignant)
  @date   2023-02-10
  @brief  :L'objectif de ce projet consiste � servir de contr�le d'acc�s d'un 
  local. Ce projet peut �tre vu au c�gep pour un certain local. Au d�but du
  programme, les LED rouge et jaune clignotent � intervalles r�guliers pour 
  montrer que le programme a �t� correctement transmis au Pic. En cons�quence, 
  l'�cran LCD affiche un message � Bienvenu aux locale 283 l'utilisateur doit 
  alors utiliser un port s�rie pour appuyer sur la touche ENTR�E afin de changer
  l'�tape. L'utilisateur doit alors entrer son num�ro d'�tudiant (entre 0 et 11)
  et entrer le bon NIP. Si le num�ro de l'�tudiant ou le NIP de l'�l�ve est
  incorrect, l'�cran affiche un refus d'acc�s et la LED rouge s'allume. Si tout 
  ce qui est entr� est exact, l?�cran affiche bienvenu tel utilisateur et la DEL
  jaune allume pour d�montrer une porte qui se d�bloque. 
  
  Environnement:
      D�veloppement: MPLAB X IDE (version 6.05)
      Compilateur: XC8 (version 2.40)
      Mat�riel: PIC 18F458,�cran LCD, DEL rouge, DEL jaune, DEL verte, bloc 
      d'allimentation, Pic kit 3, R�sistances, USB s�rie, Potentiometre,breadboard
  *   crystal, connecteur 90 degr� 
 */

/****************** Liste des INCLUDES ****************************************/
#include <xc.h>
#include "Lcd4Lignes.h"
#include "serie_458.h"
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
/********************** CONSTANTES *******************************************/
#define _XTAL_FREQ 16000000 //Constante utilis�e par __delay_ms(x). Doit = fr�q interne du uC
#define NB_CAR_NOM 20   //nom d'usager a 20 caract�res max
#define NB_NIP 4  //les nip on 4 car max 
#define NB_USAGER 12  //nombre d'usagers
#define ENTER 0x0D //touche Enter
#define ESC 0x1B   //touche escape
/********************** PROTOTYPES *******************************************/
void initialisation(void);
void gereTouche(unsigned int *etat, int *usager);
void affiche(unsigned int etat, int usager);
void flashDEL(void);
bool verifNip(int usager, char* no, int index);
/****************** VARIABLES GLOBALES ****************************************/
const unsigned char msg[] = "Lab2 MarcG";
const unsigned char enter[] = "<Enter>";
const unsigned char msg2[]= "Acces local 283";
const unsigned char msg3[]= "Entrez votre Numero Etudiant ";
const unsigned char msg4[]= "Entrez votre NIP ";
const unsigned char msg5[]= "Bonjour ";
const unsigned char msg6[]= "Acces refuse";

enum
{
    enumEtat_Depart       = 0,
    enumEtat_NoUsager    ,
    enumEtat_NIP     ,
    enumEtat_AccesOk      ,
    enumEtat_AccesRefuse  ,
    enumEtat_Max
};
 
struct stUsager
{
  char nom[NB_CAR_NOM];
  char nip[NB_NIP+1]; //un octet de plus pour le \0 qu'on devra rajouter 
}; 
//tableau des usagers.
struct stUsager g_listeUsager [] =
{
    {"Mr Zero", ""},  //pas de nip
    {"Mr Un", "1"},
    {"Mme Deux", "22"},
    {"Mr Trois", "333"},
    {"Mr Quatre", "4444"},
    {"Mme No5 ", "5"},
    {"Mr No6", "6"},
    {"Mme No7", "7"},
    {"Mr No8", "8"},
    {"Mme No9", "9"},
    {"Mr No10", "10"},
    {"Mme No11", "11"}
};

void main(void) 
{
    /* d�clarations des variables locales */
    unsigned int  etatCourant = enumEtat_Depart;
    unsigned int  etatAffiche = enumEtat_Max; //utilise pour afficher un changement d'etat. Met a max au debut pour forcer un 1er affichage
    int noUsagerCourant = -1;  //-1 lorsqu'aucun usager s�lectionn�
    initialisation();
    init_serie();
    lcd_init();
    lcd_putMessage(msg); 
    flashDEL();
    while (1)
    {
        if (kbhit() == 1) //Si une touche a �t� appuy�e
        {
            gereTouche(&etatCourant,&noUsagerCourant);
        } 
 
        // Gestion des conditions d'affichage en fonction de l'�tat courant
        if (etatAffiche != etatCourant) // il y a eu une modification d'�tat => il faut rafra�chir l'�cran
        {
            affiche(etatCourant, noUsagerCourant);
            etatAffiche = etatCourant;  //Pour ne pas r�afficher pour rien au prochain passage
        } 
    }
} //du main

/**
 * @brief Initialisation des diff�rents regesitres du PIC.
 */
void initialisation(void)
{
    TRISD = 0; //Tout le port D en sortie
    TRISC = 0; //Tout le port C en sortie
    TRISB=1;//Tout le port B en entr�
    ADCON1=7;
}

void gereTouche(unsigned int *etat, int *usager)
{
    char touche =0;
    static int indexNIP = 0;
    static char nip[NB_NIP+1];
  
       //lecture de la touche re�ue, � faire ... 
    touche = getch();
    if (touche >= '0' && touche <= '9') // si le chiffre n'est pas dans la dizaine  
    {
        if (*etat == enumEtat_NoUsager) 
        {
           lcd_ecritChar(touche); //on affiche la touche pes�e

           if(*usager==-1)// si usager est a -1
           {
                *usager =atoi(&touche); // Change la variable pour int   
           }
           else
           {
            *usager=(*usager *10) +atoi(&touche) ; // X10 au chiffre pour le d�placer unit� � la dizaine
           }
        }
        else if (*etat == enumEtat_NIP) // �tat v�rification du nip
        {
            if (indexNIP < NB_NIP) // Limite � 4 chiffres
            {
               lcd_ecritChar('*'); //on cache le nip a l'ecran
               nip[indexNIP] = touche; // met le caractere soit la touche dans indez(nip)
               indexNIP++; // incr�mente pour pouvoir entrer un nouveau chiffre
            }
        }
    }  
    if (touche==ESC) //si ESC est presser
    {
        
        if(*etat==enumEtat_NIP)
        {
            *etat=enumEtat_NoUsager; // retourne a l'�tape de l'usager
            *usager=-1;// remet la variable par d�faut
            indexNIP=0; // remet la variable par d�faut
            
        }
        else if(*etat==enumEtat_NoUsager)
        {
            *etat=enumEtat_Depart;// retourne a l'�tape du d�but
            *usager=-1;// remet la variable par d�faut
        }
        
        
    }
    if (touche==ENTER) //si touche enter presser
    {
        if(*etat==enumEtat_Depart) // si on est rendu au d�part
        {
           *etat=enumEtat_NoUsager; // passe � l'�tape d'apr�s
           *usager=-1;//variable par d�faut
        }
        
        else if(*etat==enumEtat_NoUsager)// �tape NoUsager
        {
            if(*usager<=(NB_USAGER-1)&&*usager>=0) // si plus grand que 0 et plus petit 12
            {
              *etat=enumEtat_NIP; // change d�tat pour l'�tape suivante
            } 
            else
            {
                *etat=enumEtat_AccesRefuse; // refuse l'acces 
                *usager=-1;// remet la variable par d�faut
            }  
        }      
        else if(*etat==enumEtat_NIP) // �tat du nip 
        {
            if(verifNip(*usager,nip,indexNIP)==1) // v�rifie le nip
            {
                *etat=enumEtat_AccesOk; // donne acces au local 
                indexNIP=0;// remet la variable par d�faut
            }
            else
            {
                *etat=enumEtat_AccesRefuse; // refuse l'acces 
                indexNIP=0;// remet la variable par d�faut
            }
        }
        else if(*etat==enumEtat_AccesRefuse)//accesRefuse?
        {
            *etat=enumEtat_Depart; // change d'�tat pour d�part
        }  
        else if(*etat==enumEtat_AccesOk)//accesOK?
            {
                *etat=enumEtat_Depart;// change d'�tat pour le d�part
        }
    }
}

 
/* � vous d'�crire l'ent�te */
void affiche(unsigned int etat, int usager)
{
   
    switch(etat)  //V�rification de l'�tat auquel est rendue la machine � �tats
    {
    case 0: //�tat 0
        lcd_effaceAffichage();//efface ce qui avait avant 
        lcd_putMessage(msg2);// afiche le message 2 
        lcd_gotoXY(1,3);//permet de ne pas avoir deux message sur lautre 
        lcd_putMessage(enter);//affiche Enter 
        PORTDbits.RD7=0;// �teind la del Rouge
        PORTCbits.RC0=0;// �teind la del Jaune
        
        break;
     
    case 1: //�tat 1
        lcd_effaceAffichage();//efface ce qui avait avant 
        lcd_putMessage(msg3); //Affiche entrez votre no �tudiant  ....
        lcd_gotoXY(1,3);//permet de ne pas avoir deux message sur lautre 
        lcd_putMessage(enter);//Affiche entrez votre no �tudiant  ....
        PORTDbits.RD7=0;// �teind la del Rouge
        PORTCbits.RC0=0;// �teind la del Jaune
        break;
    case 2: //�tat 2
        lcd_effaceAffichage();//efface ce qui avait avant 
        lcd_putMessage(msg4); // Affiche entrez votre Nip....
        lcd_gotoXY(1,3);//permet de ne pas avoir deux message sur lautre 
        lcd_putMessage(enter);//affiche Enter 
        PORTDbits.RD7=0;// �teind la del Rouge
        PORTCbits.RC0=0;// �teind la del Jaune
        break;
    case 3: //�tat 3
        lcd_effaceAffichage();//efface ce qui avait avant 
        lcd_putMessage(msg5); //Affiche Bonjour ....
        lcd_putMessage(g_listeUsager[usager].nom);//affiche le nom de l'usager 
        lcd_gotoXY(1,3);//permet de ne pas avoir deux message sur lautre 
        lcd_putMessage(enter);//affiche Enter 
        PORTCbits.RC0 = 1; // Allume DEL Jaune
      
        break;
    case 4: //�tat 4
        lcd_effaceAffichage();//efface ce qui avait avant 
        lcd_putMessage(msg6); // Affiche acces refuse 
        lcd_gotoXY(1,3);//permet de ne pas avoir deux message sur lautre 
        lcd_putMessage(enter);//affiche Enter 
        PORTDbits.RD7 = 1; // Allume DEL Rouge
        break;
    default:
        break;
    }  
}

void flashDEL()
{
    PORTDbits.RD7=0;// �teind la del Rouge
    PORTCbits.RC0=0;// �teind la del Jaune
    for(int i=0;i<2;i++) // Boucle de trois fois 
    {
        PORTDbits.RD7 = 1; // Allume DEL Rouge
        __delay_ms(1000);  // Attend 1 seconde 
        PORTDbits.RD7 = 0; //�teint Del Rouge
        PORTCbits.RC0 = 1; // Allume DEL Jaune
        __delay_ms(1000);  // Attend 1 seconde 
        PORTCbits.RC0 = 0; //�teint Del Jaune
    }
}
bool verifNip(int usager, char* no, int index)
{
    int verification=0;// sert de variable temporaire 
    bool resultat=0;//sert au retour 
    no[index] = '\0';// permet de finir le tableau 
    verification=strcmp(no,g_listeUsager[usager].nip);
    if(verification==0) // si il n'y a pas de diff�rence 
    {
        resultat=1;//vrai
    }
    else //aussi non
    {
        resultat=0;//fau
    }
    return resultat;
}